<?php
require ('header.php');

?>
<article>
    <p>Vous désirez connaître des informations sur un employé. </p>
    <br>
    <p>L'annaire est destiné à faciliter la localisation d’un employé à partir de différents critères.</p>
    <br>
    <p>Les critères peuvent porter sur l’index alphabétique, la recherche de noms, etc ... </p>
</article>

<?php require("footer.php"); ?>