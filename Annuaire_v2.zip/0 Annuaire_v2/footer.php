    </section>
    <footer>
        <p>&copy; BTS SIO | Lycée Pierre Poivre</a>
    </footer>
</body>
</html>