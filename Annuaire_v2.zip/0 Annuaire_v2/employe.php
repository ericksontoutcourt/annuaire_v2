<?php
require 'header.php';
require 'fonction.php';
$id = $_GET['id'];
$ligne = getEmploye($id);

?>
<article>
   <h2>Fiche employés <strong> <?php echo $ligne['nom']; ?></strong></h2>
        <table>
               <tbody>
                  </tr>
                  <tr>
                     <td>Nom</td>
                     <td><input type="text" name="nom" size="25" value ='<?php echo $ligne['nom']; ?>'></td>
                  </tr>
                  <tr>
                     <td>Pr&eacute;nom</td>
                     <td><input type="text" name="prenom" size="25"></td>
                  </tr>
                  <tr>
                     <td>Age</td>
                     <td>
                        <input type="number" name="age" size="5"></<input>
                     </td>
                  </tr>
                  <tr>
                     <td>Ville</td>
                     <td>
                        <input type="text" name="ville" size="25">
                     </td>
                  </tr>
                  <tr>
                     <td>Courriel</td>
                     <td>
                        <input type="text" name="email" size="25">
                     </td>
                  </tr>
                  <tr>
                     <td>Date d'embauche</td>
                     <td>
                        <input type="date" name="dateamb">
                     </td>
                  </tr>
                  <!--
                  <tr>
                     <td colspan="2">
                        <input type="submit" name="action" value="Envoyer">
                     </td>
                  </tr>
                  -->
               </tbody>
            </table>

    </article>  
        <?php   
            // Fermeture de la connexion
            unset($cnx);
            require("footer.php"); 

        ?>