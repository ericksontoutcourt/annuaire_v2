<?php
require ('header.php');
require 'fonction.php';
$resultats = getEmployes();

?>
<article>
   <h2>Liste des employés </h2>
   <table>
      <tr> 
        <th>#</th>
        <th> Nom </th> 
        <th> Email </th> 
        <th> Age </th> 
        <th>  Actions </th> 
      </tr>
<?php
      foreach ($resultats as $ligne) 
      {
         echo "<tr>";
            echo "<td>" . $ligne['id'] . "</td>";
            echo "<td>" . "<a href='employe.php?id=" . $ligne['id'] . "'>" . $ligne['nom'] . "</a></td>" ;
            echo "<td>" . $ligne['email'] . "</td>";
            echo "<td>" . $ligne['age'] 	. "</td>";
            if ($_GET['action'] == 1)
            {
               echo "<td>";
                  echo '<a title="Lire" href= "#"><img src="style/read.png"/></a> ';
                  echo "&nbsp;&nbsp;&nbsp;";
                  echo '<a title="Modifier" href = "#"><img src="style/edit.png"/></a> ';
                  echo "&nbsp;&nbsp;&nbsp;";
                  echo '<a title="Supprimer" href="#"><img src="style/delete.png"/></a> ';
               echo "</td>" ;
            }
            else 
            {
               echo "<td></td>" ;
            }
         echo "</tr>";
      }

      // Fermeture de la connexion
        unset($cnx);
?>

   </table>
</article>

<?php require("footer.php"); ?>